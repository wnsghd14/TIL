-- SQLite
CREATE TABLE healthcare1(
    id INTEGER PRIMARY KEY,
    sido INTEGER NOT NULL,
    gender INTEGER NOT NULL,
    age INTEGER NOT NULL,
    heiht INTEGER NOT NULL,
    weight INTEGER NOT NULL,
    waist REAL ,
    va_left REAL ,
    bolld_pressure INTEGER NOT NULL,
    smoking INTEGER NOT NULL,
    is_drinking BOOLEAN NOT NULL
    );
.mode csv
.import health.csv healthcare